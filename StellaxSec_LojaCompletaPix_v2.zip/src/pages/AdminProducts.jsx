import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { 
  Package, 
  Plus, 
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { useAdmin } from '@/contexts/AdminContext';
import ProductForm from '@/components/admin/ProductForm';
import ProductList from '@/components/admin/ProductList';

const AdminProducts = () => {
  const { isAuthenticated, products, addProduct, updateProduct, deleteProduct } = useAdmin();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const handleSubmit = (productData) => {
    const finalProductData = { ...productData };

    if (productData.image instanceof File) {
      finalProductData.image = URL.createObjectURL(productData.image);
    }
    
    if (editingProduct) {
      updateProduct(editingProduct.id, finalProductData);
      toast({
        title: "Produto atualizado!",
        description: "As alterações foram salvas com sucesso.",
      });
    } else {
      addProduct(finalProductData);
      toast({
        title: "Produto adicionado!",
        description: "Novo produto criado com sucesso.",
      });
    }
    resetForm();
  };

  const resetForm = () => {
    setEditingProduct(null);
    setShowForm(false);
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este produto?')) {
      deleteProduct(id);
      toast({
        title: "Produto excluído!",
        description: "O produto foi removido com sucesso.",
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Gerenciar Produtos - Admin StellaxSec</title>
        <meta name="description" content="Gerencie os produtos da loja StellaxSec" />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <div className="bg-black/50 border-b border-red-500/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <Link to="/admin/dashboard">
                  <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <div className="p-2 rounded-lg bg-red-500/20 border border-red-500/30">
                  <Package className="h-6 w-6 text-red-400" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Gerenciar Produtos</h1>
                  <p className="text-gray-400 text-sm">StellaxSec Admin</p>
                </div>
              </div>
              
              <Button 
                onClick={() => { setEditingProduct(null); setShowForm(true); }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Produto
              </Button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            {showForm && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-full max-w-2xl"
                >
                  <Card className="glass-effect border-white/10">
                    <CardHeader>
                      <CardTitle className="text-white">
                        {editingProduct ? 'Editar Produto' : 'Novo Produto'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ProductForm
                        onSubmit={handleSubmit}
                        onCancel={resetForm}
                        editingProduct={editingProduct}
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>
            )}

            <ProductList
              products={products}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onAddProduct={() => { setEditingProduct(null); setShowForm(true); }}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminProducts;