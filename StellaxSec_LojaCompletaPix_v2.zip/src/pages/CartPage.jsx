import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useCart } from '@/contexts/CartContext';

const CartPage = () => {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCart();

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Carrinho - StellaxSec</title>
          <meta name="description" content="Seu carrinho de compras na StellaxSec" />
        </Helmet>

        <div className="min-h-screen cyber-grid">
          <Navbar />
          
          <div className="pt-24 pb-20 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <ShoppingBag className="h-24 w-24 text-gray-400 mx-auto mb-6" />
                <h1 className="text-4xl font-bold text-white mb-4">
                  Seu carrinho está vazio
                </h1>
                <p className="text-gray-400 text-lg mb-8">
                  Que tal explorar nossos produtos incríveis?
                </p>
                <Link to="/produtos">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Explorar Produtos
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </motion.div>
            </div>
          </div>

          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Carrinho - StellaxSec</title>
        <meta name="description" content="Revise seus produtos selecionados e finalize sua compra na StellaxSec" />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <Navbar />

        <div className="pt-24 pb-20 px-4">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <h1 className="text-4xl font-bold text-white mb-4">
                Seu Carrinho
              </h1>
              <p className="text-gray-400">
                Revise seus produtos antes de finalizar a compra
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {cartItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                  >
                    <Card className="glass-effect border-white/10">
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            className="w-full md:w-24 h-24 object-cover rounded-lg"
                          />
                          
                          <div className="flex-1">
                            <h3 className="text-white font-semibold text-lg mb-2">
                              {item.name}
                            </h3>
                            <p className="text-gray-400 text-sm mb-4">
                              {item.description.substring(0, 100)}...
                            </p>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                  className="h-8 w-8 border-white/20 text-gray-300 hover:bg-white/5"
                                >
                                  <Minus className="h-4 w-4" />
                                </Button>
                                
                                <span className="text-white font-medium w-8 text-center">
                                  {item.quantity}
                                </span>
                                
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                  className="h-8 w-8 border-white/20 text-gray-300 hover:bg-white/5"
                                >
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </div>
                              
                              <div className="flex items-center space-x-4">
                                <span className="text-blue-400 font-bold text-lg">
                                  R$ {(item.price * item.quantity).toFixed(2)}
                                </span>
                                
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => removeFromCart(item.id)}
                                  className="h-8 w-8 border-red-500/20 text-red-400 hover:bg-red-500/10"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Order Summary */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="glass-effect border-white/10 sticky top-24">
                  <CardHeader>
                    <CardTitle className="text-white">Resumo do Pedido</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      {cartItems.map(item => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span className="text-gray-400">
                            {item.name} x{item.quantity}
                          </span>
                          <span className="text-white">
                            R$ {(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                    
                    <div className="border-t border-white/10 pt-4">
                      <div className="flex justify-between text-lg font-bold">
                        <span className="text-white">Total:</span>
                        <span className="text-blue-400">
                          R$ {getCartTotal().toFixed(2)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <Link to="/checkout" className="block">
                        <Button className="w-full neon-glow bg-blue-600 hover:bg-blue-700 text-white">
                          Finalizar Compra
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </Link>
                      
                      <Button 
                        variant="outline" 
                        onClick={clearCart}
                        className="w-full border-red-500/20 text-red-400 hover:bg-red-500/10"
                      >
                        Limpar Carrinho
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default CartPage;