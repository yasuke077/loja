import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Shield, Star, ArrowRight, Zap, Lock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useAdmin } from '@/contexts/AdminContext';
import { useToast } from "@/components/ui/use-toast";

const HomePage = () => {
  const { products } = useAdmin();
  const { toast } = useToast();
  const featuredProducts = products.filter(product => product.featured).slice(0, 3);

  const features = [
    {
      icon: Shield,
      title: 'Segurança Garantida',
      description: 'Todos os nossos produtos são verificados e seguros'
    },
    {
      icon: Zap,
      title: 'Acesso Instantâneo',
      description: 'Download imediato após a compra'
    },
    {
      icon: Lock,
      title: 'Conteúdo Premium',
      description: 'Material exclusivo de alta qualidade'
    },
    {
      icon: Users,
      title: 'Suporte Especializado',
      description: 'Equipe de experts em cybersecurity'
    }
  ];

  const handleToast = () => {
    toast({
      title: "🚧 Funcionalidade em breve!",
      description: "Este recurso ainda não foi implementado. Peça na sua próxima solicitação! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>StellaxSec - Loja Premium de Cybersecurity</title>
        <meta name="description" content="Descubra a melhor loja de produtos de cybersecurity do Brasil. eBooks, cursos e ferramentas premium para profissionais de segurança digital." />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <Navbar />

        {/* Hero Section */}
        <section className="pt-32 pb-20 px-4">
          <div className="max-w-7xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="mb-6 bg-blue-500/20 text-blue-300 border-blue-500/30">
                🚀 Loja Premium de Cybersecurity
              </Badge>
              
              <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
                StellaxSec
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
                Sua segurança digital começa aqui. Descubra produtos premium de 
                cybersecurity criados por especialistas para profissionais.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/produtos">
                  <Button size="lg" className="neon-glow bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                    Explorar Produtos
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button onClick={handleToast} variant="outline" size="lg" className="border-blue-500/50 text-blue-300 hover:bg-blue-500/10 px-8 py-3">
                  Saiba Mais
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold mb-4 gradient-text">
                Por que escolher a StellaxSec?
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Oferecemos a melhor experiência em produtos de cybersecurity
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <Card className="glass-effect border-white/10 hover:border-blue-500/30 transition-all duration-300 h-full">
                    <CardHeader className="text-center">
                      <feature.icon className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                      <CardTitle className="text-white">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-400 text-center">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold mb-4 gradient-text">
                Produtos em Destaque
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Nossos produtos mais populares e bem avaliados
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <Card className="glass-effect border-white/10 hover:border-blue-500/30 transition-all duration-300 overflow-hidden group">
                    <div className="relative overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <Badge className="absolute top-4 left-4 bg-blue-500/20 text-blue-300 border-blue-500/30">
                        {product.category}
                      </Badge>
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="text-white group-hover:text-blue-300 transition-colors">
                        {product.name}
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        {product.description.substring(0, 100)}...
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-blue-400">
                          R$ {product.price.toFixed(2)}
                        </span>
                        <Link to={`/produto/${product.id}`}>
                          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                            Ver Detalhes
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link to="/produtos">
                <Button size="lg" variant="outline" className="border-blue-500/50 text-blue-300 hover:bg-blue-500/10">
                  Ver Todos os Produtos
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="glass-effect border-white/10 rounded-2xl p-12 cyber-border"
            >
              <h2 className="text-4xl font-bold mb-6 gradient-text">
                Pronto para elevar sua segurança digital?
              </h2>
              <p className="text-gray-400 text-lg mb-8">
                Junte-se a milhares de profissionais que confiam na StellaxSec 
                para suas necessidades de cybersecurity.
              </p>
              <Link to="/produtos">
                <Button size="lg" className="neon-glow bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                  Começar Agora
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;