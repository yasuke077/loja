import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowLeft, ShoppingCart, Star, Download, Shield, Clock, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useAdmin } from '@/contexts/AdminContext';
import { useCart } from '@/contexts/CartContext';

const ProductDetailPage = () => {
  const { id } = useParams();
  const { products } = useAdmin();
  const { addToCart } = useCart();
  const { toast } = useToast();

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen cyber-grid flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Produto não encontrado</h1>
          <Link to="/produtos">
            <Button>Voltar aos Produtos</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao seu carrinho.`,
    });
  };

  const features = [
    {
      icon: Download,
      title: 'Download Instantâneo',
      description: 'Acesso imediato após a compra'
    },
    {
      icon: Shield,
      title: 'Conteúdo Verificado',
      description: 'Material testado e aprovado'
    },
    {
      icon: Clock,
      title: 'Suporte Vitalício',
      description: 'Atualizações e suporte inclusos'
    }
  ];

  return (
    <>
      <Helmet>
        <title>{product.name} - StellaxSec</title>
        <meta name="description" content={product.description} />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <Navbar />

        <div className="pt-24 pb-20 px-4">
          <div className="max-w-7xl mx-auto">
            {/* Breadcrumb */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <Link 
                to="/produtos" 
                className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar aos Produtos
              </Link>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Product Image */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <div className="relative overflow-hidden rounded-lg">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-96 object-cover"
                  />
                  <Badge className="absolute top-4 left-4 bg-blue-500/20 text-blue-300 border-blue-500/30">
                    {product.category}
                  </Badge>
                  {product.featured && (
                    <Badge className="absolute top-4 right-4 bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                      <Star className="h-3 w-3 mr-1" />
                      Destaque
                    </Badge>
                  )}
                </div>
              </motion.div>

              {/* Product Info */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-6"
              >
                <div>
                  <h1 className="text-4xl font-bold text-white mb-4">
                    {product.name}
                  </h1>
                  <p className="text-gray-400 text-lg leading-relaxed">
                    {product.description}
                  </p>
                </div>

                <div className="flex items-center space-x-4">
                  <span className="text-4xl font-bold text-blue-400">
                    R$ {product.price.toFixed(2)}
                  </span>
                  <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-500/30">
                    Disponível
                  </Badge>
                </div>

                <Button 
                  onClick={handleAddToCart}
                  size="lg" 
                  className="w-full neon-glow bg-blue-600 hover:bg-blue-700 text-white py-3"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Adicionar ao Carrinho
                </Button>

                {/* Features */}
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-white">O que você recebe:</h3>
                  <div className="space-y-3">
                    {features.map((feature, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <feature.icon className="h-5 w-5 text-blue-400 mt-1" />
                        <div>
                          <p className="text-white font-medium">{feature.title}</p>
                          <p className="text-gray-400 text-sm">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                     {product.productFile && (
                      <div className="flex items-start space-x-3">
                        <FileText className="h-5 w-5 text-blue-400 mt-1" />
                        <div>
                          <p className="text-white font-medium">Arquivo do Produto</p>
                          <p className="text-gray-400 text-sm">Inclui o arquivo: {product.productFile.name}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Additional Info */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-16"
            >
              <Card className="glass-effect border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Detalhes do Produto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-white font-medium mb-2">Categoria</h4>
                      <p className="text-gray-400">{product.category}</p>
                    </div>
                    <div>
                      <h4 className="text-white font-medium mb-2">Formato</h4>
                      <p className="text-gray-400">Digital</p>
                    </div>
                    <div>
                      <h4 className="text-white font-medium mb-2">Idioma</h4>
                      <p className="text-gray-400">Português</p>
                    </div>
                    <div>
                      <h4 className="text-white font-medium mb-2">Suporte</h4>
                      <p className="text-gray-400">Vitalício</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ProductDetailPage;