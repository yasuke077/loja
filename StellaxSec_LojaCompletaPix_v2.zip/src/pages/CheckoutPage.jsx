import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { CreditCard, Lock, CheckCircle, Mail, AtSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useCart } from '@/contexts/CartContext';
import { useAdmin } from '@/contexts/AdminContext';
import { FaInstagram } from 'react-icons/fa';

const CheckoutPage = () => {
  const { cartItems, getCartTotal, clearCart } = useCart();
  const { addOrder } = useAdmin();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    instagram: '',
  });

  const livePixApiKey = "RWQe/m0whXy1jsAlx98Vh2Kr7M3JKUbCKri9dtdNWHV4xK7qsYXNjwhNiuDFKjOqTTiiBCNz/y9J6RhBmkuwbtmJRQCNyeAf0PRpS6oAoq44/pAOjPwsVztWld8WNl0C0DrfLAwqZZ+g7Mw4Z3SvzgqmB3rTiKnaEK1nstsONYk";

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Create order data first
    const order = {
      customer: {
        email: formData.email,
        instagram: formData.instagram,
      },
      items: cartItems,
      total: getCartTotal(),
      paymentMethod: 'livepix'
    };

    addOrder(order);
    
    // Simulate API call and redirect
    setTimeout(() => {
      toast({
        title: "🚀 Redirecionando para o pagamento...",
        description: "Você será levado para um ambiente seguro para finalizar a compra.",
      });

      const paymentUrl = `https://livepix.gg/checkout/${livePixApiKey}?amount=${getCartTotal() * 100}&email=${formData.email}`;
      window.location.href = paymentUrl;

      clearCart();
      setIsProcessing(false);
    }, 1500);
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen cyber-grid flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Carrinho vazio</h1>
          <p className="text-gray-400">Adicione produtos ao carrinho antes de finalizar a compra.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout - StellaxSec</title>
        <meta name="description" content="Finalize sua compra de forma segura na StellaxSec" />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <Navbar />

        <div className="pt-24 pb-20 px-4">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl font-bold text-white mb-4">
                Finalizar Compra
              </h1>
              <p className="text-gray-400">
                Complete seus dados para receber o produto e processar o pagamento
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Formulário */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="glass-effect border-white/10">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Lock className="h-5 w-5 mr-2 text-green-400" />
                      Dados Para Entrega
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Email
                        </label>
                        <div className="relative">
                           <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                           <Input
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            className="pl-10 bg-black/20 border-white/20 text-white"
                            placeholder="seu@email.com"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Instagram (Opcional)
                        </label>
                        <div className="relative">
                          <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            name="instagram"
                            value={formData.instagram}
                            onChange={handleInputChange}
                            className="pl-10 bg-black/20 border-white/20 text-white"
                            placeholder="seu_usuario"
                          />
                        </div>
                      </div>

                      <div className="pt-4">
                        <Button
                          type="submit"
                          disabled={isProcessing}
                          className="w-full neon-glow bg-blue-600 hover:bg-blue-700 text-white py-3"
                        >
                          {isProcessing ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                              Processando...
                            </>
                          ) : (
                            <>
                              <CreditCard className="h-5 w-5 mr-2" />
                              Pagar R$ {getCartTotal().toFixed(2)} com LivePix
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Resumo do Pedido */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="glass-effect border-white/10">
                  <CardHeader>
                    <CardTitle className="text-white">Resumo do Pedido</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      {cartItems.map(item => (
                        <div key={item.id} className="flex justify-between">
                          <div>
                            <p className="text-white font-medium">{item.name}</p>
                            <p className="text-gray-400 text-sm">Qtd: {item.quantity}</p>
                          </div>
                          <span className="text-blue-400 font-medium">
                            R$ {(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-white/10 pt-4">
                      <div className="flex justify-between text-xl font-bold">
                        <span className="text-white">Total:</span>
                        <span className="text-blue-400">
                          R$ {getCartTotal().toFixed(2)}
                        </span>
                      </div>
                    </div>

                    <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                      <div className="flex items-center text-green-400">
                        <CheckCircle className="h-5 w-5 mr-2" />
                        <span className="font-medium">Pagamento Seguro</span>
                      </div>
                      <p className="text-green-300 text-sm mt-1">
                        Processado via LivePix com criptografia SSL
                      </p>
                    </div>

                    <div className="text-center text-gray-400 text-sm">
                      <p>Após o pagamento, você receberá:</p>
                      <ul className="mt-2 space-y-1">
                        <li>• Links de download por email</li>
                        <li>• Acesso vitalício aos produtos</li>
                        <li>• Suporte técnico incluído</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default CheckoutPage;