import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { 
  Package, 
  ShoppingCart, 
  DollarSign, 
  Users, 
  TrendingUp,
  LogOut,
  Plus,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAdmin } from '@/contexts/AdminContext';

const AdminDashboard = () => {
  const { isAuthenticated, logout, products, orders } = useAdmin();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const pendingOrders = orders.filter(order => order.status === 'pending').length;
  const completedOrders = orders.filter(order => order.status === 'completed').length;

  const stats = [
    {
      title: 'Total de Produtos',
      value: products.length,
      icon: Package,
      color: 'text-blue-400'
    },
    {
      title: 'Pedidos Pendentes',
      value: pendingOrders,
      icon: ShoppingCart,
      color: 'text-yellow-400'
    },
    {
      title: 'Receita Total',
      value: `R$ ${totalRevenue.toFixed(2)}`,
      icon: DollarSign,
      color: 'text-green-400'
    },
    {
      title: 'Pedidos Concluídos',
      value: completedOrders,
      icon: TrendingUp,
      color: 'text-purple-400'
    }
  ];

  const recentOrders = orders.slice(-5).reverse();

  return (
    <>
      <Helmet>
        <title>Dashboard Admin - StellaxSec</title>
        <meta name="description" content="Painel administrativo da StellaxSec" />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        {/* Admin Header */}
        <div className="bg-black/50 border-b border-red-500/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <div className="p-2 rounded-lg bg-red-500/20 border border-red-500/30">
                  <Package className="h-6 w-6 text-red-400" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Admin Panel</h1>
                  <p className="text-gray-400 text-sm">StellaxSec</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Link to="/">
                  <Button variant="outline" className="border-white/20 text-gray-300 hover:bg-white/5">
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Loja
                  </Button>
                </Link>
                <Button 
                  onClick={logout}
                  variant="outline" 
                  className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            {/* Welcome */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <h2 className="text-3xl font-bold text-white mb-2">
                Bem-vindo ao Dashboard
              </h2>
              <p className="text-gray-400">
                Gerencie sua loja e acompanhe as vendas
              </p>
            </motion.div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <Card className="glass-effect border-white/10">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-gray-400 text-sm">{stat.title}</p>
                          <p className="text-2xl font-bold text-white">{stat.value}</p>
                        </div>
                        <stat.icon className={`h-8 w-8 ${stat.color}`} />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mb-8"
            >
              <Card className="glass-effect border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Ações Rápidas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Link to="/admin/produtos">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                        <Package className="h-4 w-4 mr-2" />
                        Gerenciar Produtos
                      </Button>
                    </Link>
                    <Link to="/admin/pedidos">
                      <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Ver Pedidos
                      </Button>
                    </Link>
                    <Link to="/admin/produtos">
                      <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Produto
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Orders */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Card className="glass-effect border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Pedidos Recentes</CardTitle>
                </CardHeader>
                <CardContent>
                  {recentOrders.length > 0 ? (
                    <div className="space-y-4">
                      {recentOrders.map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-4 bg-black/20 rounded-lg">
                          <div>
                            <p className="text-white font-medium">{order.customer.name}</p>
                            <p className="text-gray-400 text-sm">{order.customer.email}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-blue-400 font-bold">R$ {order.total.toFixed(2)}</p>
                            <Badge 
                              variant={order.status === 'completed' ? 'default' : 'secondary'}
                              className={order.status === 'completed' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}
                            >
                              {order.status === 'pending' ? 'Pendente' : 'Concluído'}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-400 text-center py-8">
                      Nenhum pedido encontrado
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminDashboard;