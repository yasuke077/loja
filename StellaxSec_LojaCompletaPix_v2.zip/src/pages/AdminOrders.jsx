import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { 
  ShoppingCart, 
  ArrowLeft,
  CheckCircle,
  Clock,
  User,
  Mail,
  Phone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useAdmin } from '@/contexts/AdminContext';

const AdminOrders = () => {
  const { isAuthenticated, orders, updateOrderStatus } = useAdmin();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const handleStatusChange = (orderId, newStatus) => {
    updateOrderStatus(orderId, newStatus);
    toast({
      title: "Status atualizado!",
      description: `Pedido marcado como ${newStatus === 'completed' ? 'concluído' : 'pendente'}.`,
    });
  };

  const getStatusColor = (status) => {
    return status === 'completed' 
      ? 'bg-green-500/20 text-green-300 border-green-500/30'
      : 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
  };

  const getStatusText = (status) => {
    return status === 'completed' ? 'Concluído' : 'Pendente';
  };

  return (
    <>
      <Helmet>
        <title>Gerenciar Pedidos - Admin StellaxSec</title>
        <meta name="description" content="Gerencie os pedidos da loja StellaxSec" />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        {/* Admin Header */}
        <div className="bg-black/50 border-b border-red-500/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <Link to="/admin/dashboard">
                  <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <div className="p-2 rounded-lg bg-red-500/20 border border-red-500/30">
                  <ShoppingCart className="h-6 w-6 text-red-400" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Gerenciar Pedidos</h1>
                  <p className="text-gray-400 text-sm">StellaxSec Admin</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            {/* Orders List */}
            <div className="space-y-6">
              {orders.length > 0 ? (
                orders.map((order, index) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                  >
                    <Card className="glass-effect border-white/10">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-white">
                              Pedido #{order.id}
                            </CardTitle>
                            <p className="text-gray-400 text-sm">
                              {new Date(order.createdAt).toLocaleDateString('pt-BR', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                          <div className="flex items-center space-x-4">
                            <Badge className={getStatusColor(order.status)}>
                              {order.status === 'completed' ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <Clock className="h-3 w-3 mr-1" />
                              )}
                              {getStatusText(order.status)}
                            </Badge>
                            <span className="text-blue-400 font-bold text-xl">
                              R$ {order.total.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-6">
                        {/* Customer Info */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-black/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-gray-400" />
                            <div>
                              <p className="text-white font-medium">{order.customer.name}</p>
                              <p className="text-gray-400 text-sm">Nome</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Mail className="h-4 w-4 text-gray-400" />
                            <div>
                              <p className="text-white font-medium">{order.customer.email}</p>
                              <p className="text-gray-400 text-sm">Email</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-400" />
                            <div>
                              <p className="text-white font-medium">{order.customer.phone}</p>
                              <p className="text-gray-400 text-sm">Telefone</p>
                            </div>
                          </div>
                        </div>

                        {/* Order Items */}
                        <div>
                          <h4 className="text-white font-medium mb-3">Itens do Pedido</h4>
                          <div className="space-y-2">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex justify-between items-center p-3 bg-black/10 rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <img 
                                    src={item.image} 
                                    alt={item.name}
                                    className="w-12 h-12 object-cover rounded"
                                  />
                                  <div>
                                    <p className="text-white font-medium">{item.name}</p>
                                    <p className="text-gray-400 text-sm">Qtd: {item.quantity}</p>
                                  </div>
                                </div>
                                <span className="text-blue-400 font-medium">
                                  R$ {(item.price * item.quantity).toFixed(2)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex justify-end space-x-3">
                          {order.status === 'pending' ? (
                            <Button
                              onClick={() => handleStatusChange(order.id, 'completed')}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Marcar como Concluído
                            </Button>
                          ) : (
                            <Button
                              onClick={() => handleStatusChange(order.id, 'pending')}
                              variant="outline"
                              className="border-yellow-500/20 text-yellow-400 hover:bg-yellow-500/10"
                            >
                              <Clock className="h-4 w-4 mr-2" />
                              Marcar como Pendente
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-20"
                >
                  <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Nenhum pedido encontrado
                  </h3>
                  <p className="text-gray-400">
                    Os pedidos aparecerão aqui quando os clientes fizerem compras
                  </p>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminOrders;