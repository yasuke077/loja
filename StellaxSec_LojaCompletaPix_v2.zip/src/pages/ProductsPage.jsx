import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Search, Filter, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useAdmin } from '@/contexts/AdminContext';

const useQuery = () => {
  return new URLSearchParams(useLocation().search);
};

const ProductsPage = () => {
  const { products } = useAdmin();
  const query = useQuery();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const categoryFromUrl = query.get('category');
    if (categoryFromUrl) {
      setSelectedCategory(categoryFromUrl);
    }
  }, [query]);

  const categories = ['all', 'eBook', 'Curso', 'Ferramenta', 'Script'];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <Helmet>
        <title>Produtos - StellaxSec</title>
        <meta name="description" content="Explore nossa coleção completa de produtos de cybersecurity. eBooks, cursos e ferramentas premium para profissionais." />
      </Helmet>

      <div className="min-h-screen cyber-grid">
        <Navbar />

        <div className="pt-24 pb-20 px-4">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
                Nossos Produtos
              </h1>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Descubra nossa coleção completa de produtos premium de cybersecurity
              </p>
            </motion.div>

            {/* Filters */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mb-12"
            >
              <div className="glass-effect border-white/10 rounded-lg p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  {/* Search */}
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar produtos..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-black/20 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>

                  {/* Category Filter */}
                  <div className="flex gap-2 flex-wrap">
                    {categories.map(category => (
                      <Button
                        key={category}
                        variant={selectedCategory === category ? "default" : "outline"}
                        onClick={() => setSelectedCategory(category)}
                        className={selectedCategory === category 
                          ? "bg-blue-600 hover:bg-blue-700 text-white" 
                          : "border-white/20 text-gray-300 hover:bg-white/5"
                        }
                      >
                        {category === 'all' ? 'Todos' : category}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <Card className="glass-effect border-white/10 hover:border-blue-500/30 transition-all duration-300 overflow-hidden group h-full">
                    <div className="relative overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <Badge className="absolute top-4 left-4 bg-blue-500/20 text-blue-300 border-blue-500/30">
                        {product.category}
                      </Badge>
                      {product.featured && (
                        <Badge className="absolute top-4 right-4 bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                          <Star className="h-3 w-3 mr-1" />
                          Destaque
                        </Badge>
                      )}
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="text-white group-hover:text-blue-300 transition-colors">
                        {product.name}
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        {product.description.substring(0, 100)}...
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="flex-1 flex flex-col justify-end">
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-blue-400">
                          R$ {product.price.toFixed(2)}
                        </span>
                        <Link to={`/produto/${product.id}`}>
                          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                            Ver Detalhes
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20"
              >
                <p className="text-gray-400 text-lg">
                  Nenhum produto encontrado com os filtros selecionados.
                </p>
              </motion.div>
            )}
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ProductsPage;