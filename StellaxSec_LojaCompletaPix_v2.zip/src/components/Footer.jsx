import React from 'react';
import { Shield, Mail } from 'lucide-react';
import { FaInstagram, FaTiktok } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-black/50 border-t border-white/10 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e Descrição */}
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Shield className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold gradient-text">StellaxSec</span>
            </Link>
            <p className="text-gray-400 mb-4">
              Sua loja premium de produtos de cybersecurity. Oferecemos os melhores 
              ebooks, cursos e ferramentas para profissionais de segurança digital.
            </p>
            <div className="flex space-x-4">
              <a href="mailto:contato@stellaxsec.com" className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors">
                <Mail className="h-4 w-4" />
                <span>contato@stellaxsec.com</span>
              </a>
            </div>
            <div className="flex space-x-4 mt-4">
              <a href="https://instagram.com/StellaxSec" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaInstagram size={24} />
              </a>
              <a href="https://tiktok.com/@StellaxSec" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaTiktok size={24} />
              </a>
            </div>
          </div>

          {/* Links Rápidos */}
          <div>
            <span className="text-white font-semibold mb-4 block">Links Rápidos</span>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Início</Link></li>
              <li><Link to="/produtos" className="text-gray-400 hover:text-white transition-colors">Produtos</Link></li>
              <li><Link to="/carrinho" className="text-gray-400 hover:text-white transition-colors">Carrinho</Link></li>
            </ul>
          </div>

          {/* Categorias */}
          <div>
            <span className="text-white font-semibold mb-4 block">Categorias</span>
            <ul className="space-y-2">
              <li><Link to="/produtos?category=eBook" className="text-gray-400 hover:text-white transition-colors">eBooks</Link></li>
              <li><Link to="/produtos?category=Curso" className="text-gray-400 hover:text-white transition-colors">Cursos</Link></li>
              <li><Link to="/produtos?category=Ferramenta" className="text-gray-400 hover:text-white transition-colors">Ferramentas</Link></li>
              <li><Link to="/produtos?category=Script" className="text-gray-400 hover:text-white transition-colors">Scripts</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 StellaxSec. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;