import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Upload, Image as ImageIcon, FileText, X } from 'lucide-react';

const ProductForm = ({ onSubmit, onCancel, editingProduct }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    image: '',
    featured: false,
    productFile: null,
  });
  const [imagePreview, setImagePreview] = useState('');
  const [fileName, setFileName] = useState('');

  const imageInputRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (editingProduct) {
      setFormData({
        name: editingProduct.name,
        description: editingProduct.description,
        price: editingProduct.price.toString(),
        category: editingProduct.category,
        image: editingProduct.image,
        featured: editingProduct.featured || false,
        productFile: editingProduct.productFile || null,
      });
      if (typeof editingProduct.image === 'string') {
        setImagePreview(editingProduct.image);
      }
      if (editingProduct.productFile) {
        setFileName(editingProduct.productFile.name);
      }
    } else {
      setFormData({
        name: '',
        description: '',
        price: '',
        category: '',
        image: '',
        featured: false,
        productFile: null,
      });
      setImagePreview('');
      setFileName('');
    }
  }, [editingProduct]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, productFile: file });
      setFileName(file.name);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.image) {
      toast({
        title: "Imagem faltando!",
        description: "Por favor, adicione uma imagem para o produto.",
        variant: "destructive",
      });
      return;
    }
    const productData = {
      ...formData,
      price: parseFloat(formData.price)
    };
    onSubmit(productData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-white text-sm font-medium mb-2">
            Nome do Produto
          </label>
          <Input
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            required
            className="bg-black/20 border-white/20 text-white"
            placeholder="Nome do produto"
          />
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">
            Categoria
          </label>
          <Input
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            required
            className="bg-black/20 border-white/20 text-white"
            placeholder="ex: eBook, Curso, Ferramenta"
          />
        </div>
      </div>

      <div>
        <label className="block text-white text-sm font-medium mb-2">
          Descrição
        </label>
        <Textarea
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          required
          rows={4}
          className="bg-black/20 border-white/20 text-white"
          placeholder="Descrição detalhada do produto"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-white text-sm font-medium mb-2">
            Preço (R$)
          </label>
          <Input
            name="price"
            type="number"
            step="0.01"
            value={formData.price}
            onChange={handleInputChange}
            required
            className="bg-black/20 border-white/20 text-white"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">
            Imagem do Produto
          </label>
          <Input
            type="file"
            ref={imageInputRef}
            onChange={handleImageChange}
            accept="image/*"
            className="hidden"
          />
          <Button
            type="button"
            onClick={() => imageInputRef.current.click()}
            variant="outline"
            className="w-full border-white/20 text-gray-300 hover:bg-white/5"
          >
            <ImageIcon className="h-4 w-4 mr-2" />
            Selecionar Imagem
          </Button>
          {imagePreview && (
            <div className="mt-2 relative">
              <img src={imagePreview} alt="Preview" className="w-full h-32 object-cover rounded-lg" />
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="featured"
          name="featured"
          checked={formData.featured}
          onChange={handleInputChange}
          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
        />
        <label htmlFor="featured" className="text-white text-sm">
          Produto em destaque
        </label>
      </div>

      <div className="border-t border-white/10 pt-4">
        <div className="mb-4">
          <label className="block text-white text-sm font-medium mb-2">
            Arquivo do Produto (eBook, etc.)
          </label>
          <Input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <Button
            type="button"
            onClick={() => fileInputRef.current.click()}
            variant="outline"
            className="w-full border-white/20 text-gray-300 hover:bg-white/5"
          >
            <Upload className="h-4 w-4 mr-2" />
            Selecionar Arquivo
          </Button>
          {fileName && (
            <div className="mt-2 flex items-center justify-between bg-black/20 p-2 rounded-lg">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-blue-400" />
                <span className="text-sm text-gray-300">{fileName}</span>
              </div>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="h-6 w-6 text-red-400 hover:bg-red-500/10"
                onClick={() => {
                  setFormData({ ...formData, productFile: null });
                  setFileName('');
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
          <p className="text-gray-400 text-xs mt-1">
            Adicione PDFs, vídeos e outros arquivos digitais
          </p>
        </div>
      </div>

      <div className="flex space-x-4">
        <Button
          type="submit"
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
        >
          {editingProduct ? 'Atualizar' : 'Criar'} Produto
        </Button>
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="border-white/20 text-gray-300 hover:bg-white/5"
        >
          Cancelar
        </Button>
      </div>
    </form>
  );
};

export default ProductForm;