import React from 'react';
import { motion } from 'framer-motion';
import { Edit, Trash2, Star, Package, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const ProductList = ({ products, onEdit, onDelete, onAddProduct }) => {
  if (products.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-20"
      >
        <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-white mb-2">
          Nenhum produto cadastrado
        </h3>
        <p className="text-gray-400 mb-6">
          Comece criando seu primeiro produto
        </p>
        <Button 
          onClick={onAddProduct}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          Criar Primeiro Produto
        </Button>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product, index) => (
        <motion.div
          key={product.id}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: index * 0.1 }}
        >
          <Card className="glass-effect border-white/10 overflow-hidden">
            <div className="relative">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-4 left-4 flex space-x-2">
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                  {product.category}
                </Badge>
                {product.featured && (
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                    <Star className="h-3 w-3 mr-1" />
                    Destaque
                  </Badge>
                )}
              </div>
            </div>
            
            <CardContent className="p-4">
              <h3 className="text-white font-semibold text-lg mb-2">
                {product.name}
              </h3>
              <p className="text-gray-400 text-sm mb-4">
                {product.description.substring(0, 100)}...
              </p>
              
              <div className="flex items-center justify-between mb-4">
                <span className="text-blue-400 font-bold text-xl">
                  R$ {product.price.toFixed(2)}
                </span>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={() => onEdit(product)}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-blue-500/20 text-blue-400 hover:bg-blue-500/10"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Editar
                </Button>
                <Button
                  onClick={() => onDelete(product.id)}
                  variant="outline"
                  size="sm"
                  className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default ProductList;