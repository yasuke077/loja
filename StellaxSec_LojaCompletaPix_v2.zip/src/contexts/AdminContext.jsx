
import React, { createContext, useContext, useState, useEffect } from 'react';

const AdminContext = createContext();

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin deve ser usado dentro de um AdminProvider');
  }
  return context;
};

export const AdminProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const adminAuth = localStorage.getItem('stellaxsec_admin_auth');
    if (adminAuth === 'authenticated') {
      setIsAuthenticated(true);
    }

    const savedProducts = localStorage.getItem('stellaxsec_products');
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    } else {
      // Produtos iniciais de exemplo
      const initialProducts = [
        {
          id: '1',
          name: 'Curso Completo de Ethical Hacking',
          description: 'Aprenda técnicas avançadas de ethical hacking e pentest com este curso completo. Inclui laboratórios práticos e certificado.',
          price: 297.00,
          category: 'Curso',
          image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=500',
          files: [],
          featured: true,
          createdAt: new Date().toISOString()
        },
        {
          id: '2',
          name: 'eBook: Segurança em Redes',
          description: 'Guia completo sobre segurança em redes corporativas. Técnicas de proteção e detecção de ameaças.',
          price: 89.90,
          category: 'eBook',
          image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=500',
          files: [],
          featured: true,
          createdAt: new Date().toISOString()
        },
        {
          id: '3',
          name: 'Kit de Ferramentas OSINT',
          description: 'Coleção completa de ferramentas e scripts para Open Source Intelligence. Inclui tutoriais e casos práticos.',
          price: 149.90,
          category: 'Ferramenta',
          image: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=500',
          files: [],
          featured: false,
          createdAt: new Date().toISOString()
        }
      ];
      setProducts(initialProducts);
      localStorage.setItem('stellaxsec_products', JSON.stringify(initialProducts));
    }

    const savedOrders = localStorage.getItem('stellaxsec_orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('stellaxsec_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('stellaxsec_orders', JSON.stringify(orders));
  }, [orders]);

  const login = (password) => {
    // Senha admin simples para demonstração
    if (password === 'stellaxsec2024') {
      setIsAuthenticated(true);
      localStorage.setItem('stellaxsec_admin_auth', 'authenticated');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('stellaxsec_admin_auth');
  };

  const addProduct = (product) => {
    const newProduct = {
      ...product,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id, updatedProduct) => {
    setProducts(prev =>
      prev.map(product =>
        product.id === id ? { ...product, ...updatedProduct } : product
      )
    );
  };

  const deleteProduct = (id) => {
    setProducts(prev => prev.filter(product => product.id !== id));
  };

  const addOrder = (order) => {
    const newOrder = {
      ...order,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      status: 'pending'
    };
    setOrders(prev => [...prev, newOrder]);
  };

  const updateOrderStatus = (id, status) => {
    setOrders(prev =>
      prev.map(order =>
        order.id === id ? { ...order, status } : order
      )
    );
  };

  return (
    <AdminContext.Provider value={{
      isAuthenticated,
      products,
      orders,
      login,
      logout,
      addProduct,
      updateProduct,
      deleteProduct,
      addOrder,
      updateOrderStatus
    }}>
      {children}
    </AdminContext.Provider>
  );
};
