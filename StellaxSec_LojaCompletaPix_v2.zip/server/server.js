
const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

const MERCADO_PAGO_TOKEN = "APP_USR-7440440283931023-072718-4b5a58bf8ffef27632b45f6b682ff3ca-227185410";
const BREVO_API_KEY = "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";

app.post('/pix', async (req, res) => {
    const { email } = req.body;
    try {
        const response = await axios.post('https://api.mercadopago.com/v1/payments', {
            transaction_amount: 5.00,
            description: "Produto Hacker",
            payment_method_id: "pix",
            payer: { email: email }
        }, {
            headers: { Authorization: `Bearer ${MERCADO_PAGO_TOKEN}` }
        });

        const data = response.data;
        res.json({
            qr_code: data.point_of_interaction.transaction_data.qr_code,
            qr_code_base64: data.point_of_interaction.transaction_data.qr_code_base64,
            payment_id: data.id
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/webhook', async (req, res) => {
    const paymentId = req.body.data?.id;
    if (!paymentId) return res.sendStatus(400);

    try {
        const payment = await axios.get(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
            headers: { Authorization: `Bearer ${MERCADO_PAGO_TOKEN}` }
        });

        if (payment.data.status === "approved") {
            const email = payment.data.payer.email;
            await axios.post("https://api.brevo.com/v3/smtp/email", {
                sender: { name: "StellaxSec Shop", email: "noreply@stellaxsec.com" },
                to: [{ email }],
                subject: "Seu produto StellaxSec chegou!",
                htmlContent: "<p>Olá! Obrigado pela compra. Segue seu produto em anexo.</p>",
                attachment: [{
                    url: "https://stellaxsec-assets.com/produto-hacker.zip",
                    name: "produto-hacker.zip"
                }]
            }, {
                headers: {
                    "api-key": BREVO_API_KEY,
                    "Content-Type": "application/json"
                }
            });
        }

        res.sendStatus(200);
    } catch (err) {
        res.sendStatus(500);
    }
});

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
